package graphical;

import java.io.*;

public class SceneDesigner {
	String source_folder = "";
	File sceneFile = new File(source_folder + "Scene");
	Cell[][] scene1Array = new Cell[22][12];
	
	
	public void read(int scene) throws IOException {
		File sceneFile = new File(source_folder + "Scene");
		BufferedReader br = new BufferedReader(new FileReader(sceneFile));
		

	
	
	}
}
